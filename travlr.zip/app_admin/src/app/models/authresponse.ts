export class Authresponse {
    token: string = '';
  }
  


